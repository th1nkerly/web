import * as universal from "../../../../src/routes/tools/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/tools/+page.svelte";