<script>
	// import welcome from '$lib/images/svelte-welcome.webp'; 
	import welcome_fallback from '$lib/images/mind.png';
	import cat from '$lib/images/cat.jpg';
	import cat2 from '$lib/images/cat2.jpg';
	import cats from '$lib/images/cats.png';
	import kitten from '$lib/images/kitten.jpg';
	import kittens from '$lib/images/kittens.png';

	
	
</script>
<svelte:head>
	<title>Gallery</title>
	<meta name="description" content="About this app" />
</svelte:head>


	<h1>Галерея</h1>
	<div class="text-column">

			<img src={welcome_fallback} alt="Welcome" />

			<img src={cat} alt="cat" />

			<img src={cat2} alt="cat2" />
	
			<img src={kitten} alt="kitten" />

			<img src={kittens} alt="kittens" />

			<img src={cats} alt="cats" />
		
</div>

<style>

	h1 {
		width: 100%;
		text-size-adjust: 60px;
	}


	.text-column {
		display: inline-table;
		width: 80%;
		
		
	}



	img {
		display: inline;
		position: relative;
		width: 50%;
		height: 50%;
		top: 10px;
		right: 10px;
		
		
	}
</style>

