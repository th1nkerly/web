<svelte:head>
	<title>Tools</title>
	<meta name="description" content="About this app" />
</svelte:head>

<div class="text-column">
	<h1>Это инструменты для рисования</h1>
	<p>
		карандаш
	</p>	
	<p>
		ручка
	</p>	
	<p>
		ластик
	</p>	
	<p>
		краски
	</p>		
	<p>
		фигуры
	</p>	
	<p>
		распылитиль
	</p>	
	<p>
		кисть
	</p>	
	<p>
		размытие
	</p>	
	<p>
		штамп
	</p>	
	<p>
		корректор
	</p>	

</div>
